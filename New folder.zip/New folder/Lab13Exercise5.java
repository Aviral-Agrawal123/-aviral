package cg.eis.p1;
import java.util.*;

interface Fact
{
	public void factorial(int num);
}
class Lab13Exercise5 
{
	public void factorial1(int num)
	{
		int fact=1;
		if(num==0)
			System.out.println("Factorial is:1");
			else
			{
				for(int i=1;i<=num;i++)
				{
					fact=fact*i;
				}
				System.out.println("Factorial is: "+fact);
			}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the number to find the factorial:");
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		Lab13Exercise5  fac=new Lab13Exercise5 ();
		Fact fa=fac::factorial1;
		fa.factorial(num);


	}

}
