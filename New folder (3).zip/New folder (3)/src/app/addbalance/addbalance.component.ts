import { Component, OnInit } from '@angular/core';
import data from '../../data/details.json'

@Component({
  selector: 'app-addbalance',
  templateUrl: './addbalance.component.html',
  styleUrls: ['./addbalance.component.css']
})
export class AddbalanceComponent implements OnInit {
array=data
flag=false
array1=[];
  constructor() { }

  ngOnInit() {
  }

  find(number){
    this.array.forEach(element => {
      if(element.accNum==number)
      {
        this.array1.push(element)
      }
    });
    this.flag=true
  }
  update(number, amount){
    this.array.forEach(element => {
      if(element.accNum==number)
      {
        let temp=element.balance
        element.balance=temp+amount
      }
    });
    this.flag=true
  }
}
