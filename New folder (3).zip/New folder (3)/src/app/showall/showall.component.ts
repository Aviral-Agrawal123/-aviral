import { Component, OnInit } from '@angular/core';
import data from '../../data/details.json'
@Component({
  selector: 'app-showall',
  templateUrl: './showall.component.html',
  styleUrls: ['./showall.component.css']
})
export class ShowallComponent implements OnInit {
array=data
  constructor() { }

  ngOnInit() {
  }

}
