import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { CreateuserComponent } from './createuser/createuser.component';
import { SearchuserComponent } from './searchuser/searchuser.component';
import { FormsModule } from '@angular/forms';
import { FilterPipe } from './filter.pipe';
import { AddbalanceComponent } from './addbalance/addbalance.component';
import { TransferComponent } from './transfer/transfer.component';
import { ShowallComponent } from './showall/showall.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CreateuserComponent,
    SearchuserComponent,
    FilterPipe,
    AddbalanceComponent,
    TransferComponent,
    ShowallComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
