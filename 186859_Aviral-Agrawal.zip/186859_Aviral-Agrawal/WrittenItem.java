

public class WrittenItem extends Item 
{
	private String authorName;
	private int age;
	public WrittenItem()
	{
		
	}
	public WrittenItem(int idNo, String title, int copies, String authorName, int age) {
		super();
		this.authorName=authorName;
		this.age=age;
	}
	public String getAuthorName()
	{
		return authorName;
	}
	public void setAuthorName(String authorName)
	{
		this.authorName=authorName;
	}
	public int getAge()
	{
		return age;
	}
	public void setAge(int age)
	{
		this.age=age;
	}
	@Override
	public String toString()
	{
		System.out.println("Author : "+authorName);
		System.out.println("Age of the author is : "+age);
		return "WrittenItem [authorName=" + authorName + ", age=" +age + "]";
	}
	@Override
	public void equals() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void CheckIn() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void CheckOut() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void addItem() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void printDetails() {
		// TODO Auto-generated method stub
		
	}

}
