
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
public class Lab11 
{
	public static void main(String[] args)
	{
		System.out.println("inside : "+ Thread.currentThread().getName());
		
		System.out.println("Creating Services");
		ExecutorService executorService= Executors.newSingleThreadExecutor();
		
		System.out.println("Creating Runnable");
		Runnable runnable=() ->
		{
			System.out.println("inside : "+Thread.currentThread().getName());
		};
		
		System.out.println("Submit task specified by the runnable to the execution");
		executorService.submit(runnable);
		executorService.submit(runnable);
		executorService.submit(runnable);
		
	}

}
