import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map.Entry;

public class Lab9Exercise2 {

	public static void countCharacter(String inputString) 
	{
		HashMap<Character, Integer>charCountMap=new HashMap<Character,Integer>();
		char[] strArray=inputString.toCharArray();
		for(char c:strArray)
		{
			if(charCountMap.containsKey(c))
			{
				
				charCountMap.put(c,  charCountMap.get(c) +1);
			}
			else
			{
				charCountMap.put(c, 1);  
			}
		}
			
		for(Entry<Character,Integer>entry: charCountMap.entrySet())
		{
			System.out.println(entry.getKey() +" "+entry.getValue());
		}
	}
	public static void main(String[] args) throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter string");
		String str=br.readLine();
		countCharacter(str);
	}
	

}
