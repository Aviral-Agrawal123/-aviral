
import java.util.Scanner;

public class UserDefinedException extends Exception 
{

	
	public UserDefinedException(String str)
	{
		System.out.println(str);
	}
}
