
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Lab8Exercise6 {

	public static void main(String[] args) throws Throwable {
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the Date in dd/MM/yyyy");
		String mydate=br.readLine();
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		Date d1=sdf.parse(mydate); 
		System.out.println("The Date is: "+d1);
		
		Date d2=new Date();
		System.out.println("System date is : "+d2.getDate());
		
		System.out.println(Math.abs(d1.getDate()-d2.getDate()));
		System.out.println(Math.abs(d1.getMonth()-d2.getMonth()));
		System.out.println(Math.abs(d1.getYear()-d2.getYear()));
	}

}
