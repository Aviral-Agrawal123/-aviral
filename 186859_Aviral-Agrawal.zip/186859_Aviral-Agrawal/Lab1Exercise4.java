import java.util.Scanner;
class Lab1Exercise4
{
	public static boolean checkNumber(int n)
	{
		int r;
		while(n>1)
		{
		r=n%2;
		n=n/2;
		if(r==1)
		return false;
		}
		return true;
}
	
	public static void main (String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		int n=sc.nextInt();
		boolean res=checkNumber(n);
		if(res)
		System.out.println("It is a power of 2");
		else
		System.out.println("It is not a power of 2");
	}
} 
