
import java.util.*;

public class Lab5Exercise3 {

	public static void main(String[] args) {
		
		int n,z;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter limit");
		n=sc.nextInt();
		for(int i=2;i<n;i++)
		{
			z=0;
			for(int j=2;j<i;j++)
			{
				if(i%j==0)
					z=1;
			}
			if(z==0)
				System.out.println(i);
		}

	}

}
