

import java.util.Date;

public class Lab10Exercise2 implements Runnable
{

	public static void main(String[] args) 
	{
		Lab10Exercise2 t1= new Lab10Exercise2();
		Thread Threadt1=new Thread(t1);
		Threadt1.start();
	}

	public void run()
	{
		System.out.println("Thread");
		System.out.println(new Date());
		int i=1;
		while(i<=10)
		{
			try
			{
				Thread.sleep(10000);
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
			System.out.println(new Date());
		}
	}

}
