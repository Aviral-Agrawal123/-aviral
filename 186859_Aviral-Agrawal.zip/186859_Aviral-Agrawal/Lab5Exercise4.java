
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class Lab5Exercise4 {
	private static Pattern usrNamePtrn=Pattern.compile("Aviral");
	public static String validateUserName(String userName)
	{
		Matcher mtch=usrNamePtrn.matcher(userName);
		if(mtch.matches())
		{
			return "name matched";
		}
		return "com.cg.UserDefinedException";
	}

	public static void main(String[] args) {
		
		System.out.println("if no name given" +validateUserName(""));
		System.out.println("Is 'Aviral' a valid user name?  "+validateUserName("Aviral"));
		}

}