

public class Lab8Exercise7 {

	public static void main(String[] args) {
		

	}

}
