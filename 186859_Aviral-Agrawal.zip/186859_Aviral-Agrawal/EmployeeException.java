
public class EmployeeException extends Exception {
	public EmployeeException(String str)
	{
		System.out.println(str);
	}

}
