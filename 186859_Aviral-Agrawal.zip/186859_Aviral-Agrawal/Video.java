
public class Video extends MediaItem 
{
	private String director;
	private String genre;
	private int year;
	public Video()
	{
		
	}
	
	public Video(int idNo, String title, int copies, String director, String genre, int year)
	{
		super();
		this.director=director;
		this.genre=genre;
		this.year=year;
	}
	public String getDirector()
	{
		return director;
	}
	public void setDirector(String director)
	{
		this.director=director;
	}
	
	public String getGenre()
	{
		return genre;
	}
	public void setGenre(String genre)
	{
		this.genre=genre;
	}
	public int getYear()
	{
		return year;
	}
	public void setYear(int year)
	{
		this.year=year;
	}
	
	@Override
	public String toString()
	{
		super.toString();
		System.out.println("Director is : "+director);
		System.out.println("Genre is "+genre);
		System.out.println("Release Year is : "+year);
		return "Director is " +director + "The genre is "+genre +"Release year is "+year;
	}

	@Override
	public void equals() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void CheckIn() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void CheckOut() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addItem() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printDetails() {
		// TODO Auto-generated method stub
		
	}
}
