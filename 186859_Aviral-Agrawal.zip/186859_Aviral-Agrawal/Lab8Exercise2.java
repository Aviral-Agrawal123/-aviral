
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Lab8Exercise2 {

	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter File Name");
		String filename=br.readLine();
		System.out.println("Entered filename is "+filename);
		String Line=null;
		try
		{
			FileReader filereader=new FileReader(filename);
			BufferedReader bufr=new BufferedReader(filereader);
			int count=1;
			while((Line=bufr.readLine())!=null)
			{
				System.out.println(count+" "+Line);
				count++;
			}
				bufr.close();
		}
		catch(IOException ex)
		{
			System.out.println("Error in : "+filename);
		}
	}

}
