
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

public class Lab8Exercise4 {

	public static void main(String[] args) throws IOException 
	{
		
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter file name");
	String file=br.readLine();
	File f=new File(file);
	
	if(f.exists())
	{
		System.out.println("File Exists");
		System.out.println("Length of File "+f.length());
	}
	else
		System.out.println("File doesnot Exists");
	if(f.canExecute())
		System.out.println("File executes");
	if(f.canRead())
		System.out.println("File Read");
	if(f.canWrite())
		System.out.println("File Writes");
	System.out.println("file name is "+file);
	String type[]=file.split("\\.");
	System.out.println("file type is "+type[1]);
	
	
	
	}

}
