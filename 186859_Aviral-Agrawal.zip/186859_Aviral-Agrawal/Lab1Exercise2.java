
import java.util.Scanner;
class Lab1Exercise2
{
	public static int calculatediff(int n)
	{
		int sum=0;
		int diff=0;
		int SqSum=0;
		int SumSq=0;
		for(int i=0;i<=n;i++)
		{
			SqSum=SqSum+i*i;
			sum=sum+i;
			}
		SumSq=sum*sum;
		diff=SumSq-SqSum;
                return diff;

	}
	public static void main (String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter n");
		int n=sc.nextInt();
		int diff=calculatediff(n);
		System.out.println("The diff is :"+diff);
	}
}

