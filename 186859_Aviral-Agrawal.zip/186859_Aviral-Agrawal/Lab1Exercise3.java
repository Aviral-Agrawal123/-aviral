
import java.util.Scanner;
class Lab1Exercise3
{
	public static boolean checkNumber(int n)
	{
	boolean flag=false;
	int lastdigit=n%10;
	n=n/10;
	while(n>0)
	{
	if(lastdigit<n%10)
	{
	flag=true;
	break;
	}
	lastdigit=n%10;
	n=n/10;
}

if(flag)
	{
	System.out.println("It is Not a Increasing Number");
	}
	else
	{
	System.out.println("It is a Increasing Number");
	}
return flag;
}
	public static void main (String[] args)
	{
	int a;
	System.out.println("Enter the Number");
	Scanner sc=new Scanner(System.in);
	a=sc.nextInt();
	checkNumber(a);
	}
}
