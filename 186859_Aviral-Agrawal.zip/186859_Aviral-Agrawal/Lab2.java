package cg;
import java.util.Scanner;

import cg.eis.p1.Book;
import cg.eis.p1.CD;
import cg.eis.p1.Item;
import cg.eis.p1.Journal;
import cg.eis.p1.Video;

import java.util.Scanner;

public class Lab2 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Item it;
		int idNo,copies;
		String title;
		int age=50, yearofPublished,year;
		String director, genre;
		String authorname, artist;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Item ID: ");
		idNo=sc.nextInt();
		System.out.println("Enter the number of copies of the item: ");
		copies=sc.nextInt();
		System.out.println("Enter the title of the item: ");
		title=sc.next();
		
		System.out.println("Select the option from the list provided:");
		System.out.println("1, Book");
		System.out.println("2, Journal");
		System.out.println("3, Video");
		System.out.println("4, CD");
		
		int ch=sc.nextInt();
		do
		{
			switch(ch)
			{
			case 1 : System.out.println("Enter the name of the author of the book: ");
			         authorname=sc.next();
			         System.out.println("Enter the age of the author:");
			         age=sc.nextInt();
			         it=new Book(idNo,title,copies,authorname,age);
			         //it.printDetails();
			         it.toString();
			         break;
			         
			case 2 : System.out.println("Enter the name of the author: ");
	         authorname=sc.next();
	         System.out.println("Enter the age of the author:");
	         age=sc.nextInt();
	         System.out.println("Enter published year:");
	         yearofPublished=sc.nextInt();
	         it=new Journal(idNo, title, copies, authorname, age, yearofPublished);
	         //it.printDetails();
	         it.toString();
	         break;
	         
			case 3 : System.out.println("Enter Director Name: ");
	         director=sc.next();
	         System.out.println("Enter the genre of the movie/video:");
	         genre=sc.next();
	         System.out.println("Enter the released year:");
	         year=sc.nextInt();
	         it=new Video(idNo,title,copies,director,genre,year);
	         //it.printDetails();
	         it.toString();
	         break;
	         
			case 4 : System.out.println("Enter Artist Name: ");
	         artist=sc.next();
	         System.out.println("Enter the genre:");
	         genre=sc.next();
	         it=new CD(artist,genre,idNo,title,copies);
	         //it.printDetails();
	         it.toString();
	         break;
	         
	         default: System.out.println("Please select a valid option:-");
	         break;
			         
			}
			System.out.println("Select the option from the list provided: ");
			System.out.println("1, Book");
			System.out.println("2, Journal");
			System.out.println("1, Video");
			System.out.println("1, CD");
		 
			ch=sc.nextInt();
		}
		while(ch!=0);
		
		
		}
		

	}