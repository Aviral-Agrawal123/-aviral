
import java.util.Scanner;

public class Lab3Exercise1 {
public static int getSecondSmallest(int arr[], int len)
{
	int temp;
	for(int i=0; i<len; i++)
	{
		for(int j=i+1; j<len;j++)
		{
			if(arr[i]>arr[j])
			{
				temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
				
			}
		}
	}
return arr[1];
}
public static void main(String[] args)
{
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter Size of the Array");
	int len=sc.nextInt();
	
	int arr[]=new int[len];
	System.out.println("Enter the "+len+" elements");
	for(int i=0; i<len;i++)
	{
		int input=sc.nextInt();
		arr[i]=input;
	}
	for(int i=0; i<len;i++)
	{
		System.out.println("arr["+i+"] :" +arr[i]);
		}
	System.out.println("The Second Smallest Element in the Array is "+getSecondSmallest(arr, len));
}
}