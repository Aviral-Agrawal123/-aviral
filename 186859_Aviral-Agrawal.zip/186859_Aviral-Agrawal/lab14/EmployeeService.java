package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public interface EmployeeService {
	public Employee addEmployee(Employee emp) ;
		
	
	public Employee getEmployee(int eid);
	
}
