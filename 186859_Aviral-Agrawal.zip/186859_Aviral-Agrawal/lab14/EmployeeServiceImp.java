package com.cg.eis.service;

import java.util.HashMap;

import com.cg.eis.bean.Employee;

public class EmployeeServiceImp implements EmployeeService {
	private static HashMap<Integer,Employee> employees=new HashMap<>();
	public Employee addEmployee(Employee emp) {
		employees.put(emp.getId(), emp);
		System.out.println("Employee added");
		return emp;
	}
	public Employee getEmployee(int e_id) {
		Employee emp=employees.get(e_id);
		return emp;
	}
	

}
