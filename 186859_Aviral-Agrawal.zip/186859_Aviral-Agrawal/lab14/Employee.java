package com.cg.eis.bean;

public class Employee {
	private int id;
	private String Ename,desig,insurScheme;
	private double salary;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEname() {
		return Ename;
	}
	public void setEname(String Ename) {
		this.Ename = Ename;
	}
	public String getdesig() {
		return desig;
	}
	public void setdesig(String desig) {
		this.desig = desig;
	}
	public String getinsurScheme() {
		return insurScheme;
	}
	public void setinsurScheme(String insurScheme) {
		this.insurScheme = insurScheme;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String toString() {
		return "Employee[id="+ id+",Ename="+Ename+",desig="+desig+",insurScheme="+insurScheme+",salary="+salary+"]";
	}
	
	

}
