package com.cg.eis.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validation {

	public boolean validateId(int eid) {
		String id=Integer.toString(eid);
		Pattern pa=Pattern.compile("[0-9]{3}");
		Matcher m=pa.matcher(id);
                return m.matches();
	}

	public boolean validateName(String name) {
		Pattern p=Pattern.compile("[A-Z][a-z]{2,}");
		Matcher m=pt.matcher(name);
		
		
		return m.matches();
	}
	

}
