
public class Lab5Exercise1 {
	private String red;
	private String blue;
	private String yellow;
	
	public Lab5Exercise1() {
		
	}

	public Lab5Exercise1(String red, String blue, String yellow) {
		super();
		this.red = red;
		this.blue = blue;
		this.yellow = yellow;
	}

	public String getRed() {
		return red;
	}

	public void setRed(String red) {
		this.red = red;
	}

	public String getBlue() {
		return blue;
	}

	public void setBlue(String blue) {
		this.blue = blue;
	}

	public String getYellow() {
		return yellow;
	}

	public void setYellow(String yellow) {
		this.yellow = yellow;
	}
	
	public String selectRed()
	{
		System.out.println("Red");
		return "stop";
	}

	public String selectYellow()
	{
		System.out.println("Yellow");
		return "ready";
	}
	
	public String selectGreen()
	{
		System.out.println("Green");
		return "start";
		
	}
}
