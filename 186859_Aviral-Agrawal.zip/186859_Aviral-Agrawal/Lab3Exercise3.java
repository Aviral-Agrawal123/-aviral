
import java.util.Arrays;
import java.util.Scanner;

public class Lab3Exercise3 {
	public static int[] getSort(int arr[])
	{
		int temp, i=0;
		while(i<arr.length) {
			int res=0;
			temp =arr[i];
			while(temp!=0)
			{
				res=res*10+(temp%10);
				temp=temp/10;
			}
			arr[i++]=res;
			res=0;
			temp=0;
		}
		return arr;
	}
public static void main(String[] args)
{
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter Size of Array");
	int length=sc.nextInt();
	int arr[]=new int[length];
	System.out.println("Enter elements");
	for(int i=0; i<arr.length;i++)
	{
		arr[i]=sc.nextInt();
	}
	for(int i=0; i<arr.length;i++)
	{
		System.out.println("Elements Before Reversing : "+arr[i]);
		}
	
	getSort(arr);
	
	
	for (int i=0;i<arr.length;i++) 
	{
		System.out.println("Resulting Array is "+arr[i]);
	
	}
}
}