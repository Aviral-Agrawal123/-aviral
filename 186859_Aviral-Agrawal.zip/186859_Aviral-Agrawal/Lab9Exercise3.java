import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Lab9Exercise3 
{
	public static Map getSquares(int ch[])
	{
		Map<Integer,Integer> ma1=new HashMap<Integer,Integer>();
		int len=ch.length;
		for(int i=0;i<len;i++)
		{
			int power=(int)Math.pow(ch[i], 2);
			ma1.put(ch[i], power);
		}
	return ma1;
	}
	
	public static void main(String[] args) 
	{
	  Scanner sc=new Scanner(System.in);
	  System.out.println("Enter the length");
	  int len=sc.nextInt();
	  int c[]=new int[len];
	  System.out.println("Enter the elements");
	  for(int i=0;i<len;i++)
	  {
		  c[i]=sc.nextInt();
	  }

	  Map ms=getSquares(c);
	  System.out.println(m);
	}

}
