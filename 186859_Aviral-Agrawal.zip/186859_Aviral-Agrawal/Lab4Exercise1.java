
import java.io.*;
import java.math.*;
import java.util.*;

public class Lab4Exercise1
{

	public static void main(String args[]) {
		
		int count=0;
		int temp=0;
		int sum=0;
		int power=0;
		
		System.out.println("Enter Number");
	    Scanner console = new Scanner(System.in);
		int num= console.nextInt();
	    int n=num;
	    
		while(n!=0)
		{
			temp=n%10;
			power=(int) Math.pow(temp,3);
			sum=sum+power;
			count++;
			n=n/10;		
		}
		System.out.println("Sum of cube of "+count+
				" digits is "+sum);
		
		

	}

}