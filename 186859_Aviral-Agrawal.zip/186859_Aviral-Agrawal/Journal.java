

public class Journal extends WrittenItem 
{
private int yearOfPublished;
public Journal()
{
	
}
public Journal(int idNo, String title, int copies, String name, int age, int yearofPublished)
{
super();
this.yearOfPublished=yearOfPublished;
}

public int getYearOfPublished()
{
	return yearOfPublished;
}
public void setYearOfPublished(int yearOfPublished)
{
	this.yearOfPublished=yearOfPublished;
}
@Override
public String toString()
{
	return super.toString();
}

@Override
public void equals()
{
	
}

@Override
public void CheckIn()
{
	
}

@Override
public void CheckOut()
{
	
}

@Override
public void addItem()
{
	
}

@Override
public void printDetails()
{
	super.toString();
	this.toString();
}
}