

public abstract class MediaItem extends Item
{
	public MediaItem()
	{
		
	}
	
	public MediaItem(int idNo, String title, int copies)
	{
		super(idNo,title,copies);
	}
	@Override
	public String toString()
	{
		return "MediaItem[]";
	}
}
