

public class CD extends MediaItem
{
private String artist;
private String genre;
public CD()
{
	
}

public CD(String artist, String genre, int idNo, String title, int copies )
{
	super();
	this.artist=artist;
	this.genre=genre;
}
public String getArtist()
{
	return artist;
}
public void setArtist(String artist)
{
	this.artist=artist;
}
public String getGenre()
{
	return genre;
}
public void setGenre(String genre)
{
	this.genre=genre;
}

public String toString()
{
	super.toString();
	System.out.println("Artist : "+artist);
	System.out.println("Genre : +genre");
	return "CD[Artist ="+artist +"Genre ="+genre +"]";
}

public void addItem()
{
}

public void CheckIn()
{
}


public void CheckOut()
{
}

public void equals()
{
}


public void printDetails()
{
	toString();
}
}
