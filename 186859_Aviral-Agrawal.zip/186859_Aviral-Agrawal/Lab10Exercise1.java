import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.imageio.stream.FileCacheImageInputStream;

public class Lab10Exercise1 
{
	FileInputStream fromFile;
	FileOutputStream toFile;
	
	public void init(String arg1, String arg2) throws FileNotFoundException
	{
		try {
			fromFile=new FileInputStream(arg1);
			toFile=new FileOutputStream(arg2);
		}
	
	catch(FileNotFoundException fe)
		{
		System.out.println("Exception: "+fe);
		throw fe;
		}
	}
	
	public void copyContents() throws IOException, InterruptedException
	{
		
		try {
			int i=fromFile.read();
			int chaCount=0;
			while(i!=1)

		{
				chaCount++;
				if(chaCount==10)
				{
					System.out.println("10 characters copied");
					chaCount=0;
					Thread.sleep(5000);
				}
				toFile.write(i);
				i=fromFile.read();
		}
	}
		catch(IOException ioe)
		{
			System.out.println("Exception ->:"+ioe);
			throw ioe;
		}
		finally
		{
			if(fromFile!=null)
			{
				fromFile.close();  
			}
			if(toFile!=null)
			{
				toFile.close();  
			}
		}
	}

	public static void main(String[] args) throws InterruptedException
	{
		Lab10Exercise1 c1=new Lab10Exercise1();
		try {
			c1.init("Avi.txt", "Avi2.txt");
			c1.copyContents();
		}
		catch(IOException e)
		{
			System.out.println("Catch "+e);
			
		}

	}

}
