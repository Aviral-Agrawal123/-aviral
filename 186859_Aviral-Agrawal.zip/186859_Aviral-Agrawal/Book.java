


public class Book extends WrittenItem 
{
	public Book() {
		
	}
	public Book(int idNo, String title, int copies, String name, int age)
	{
		super(idNo, title, copies, name, age);
	}


	public String toString()
	{
		return "Book []";
	}
	

	public void equals()
	{
	
	}
	

	public void CheckIn()
	{
	
	}
	

	public void CheckOut()
	{
	
	}
	

	public void addItem()
	{
	
	}
	

	public void printDetails()
	{
	
	}
	
	}

