

public abstract class Item
{
	private int idNo;
	private String title; private int copies;
	
	public Item()
	{
		
	}
	
	public Item(int idNo, String title, int copies) {
		super();
		this.idNo=idNo;
		this.title=title;
		this.copies=copies;
	}
	
	public int getIdNo()
	{
		return idNo;
	}
	
	public void setIdNo(int idNo)
	{
		this.idNo=idNo;
	}

	public String getTitle()
	{
		return title;
	}
	
	public String setTitle(String title)
	{
		return this.title=title;
	}
	
	public int getCopies()
	{
		return copies;
	}

	public void setCopies(int copies)
	{
		this.copies=copies;
	}
	

	public String toString()
	{
		System.out.println("ID No is :"+idNo);
		System.out.println("Title is :"+title);
		System.out.println("Copies is :"+copies);
		return "Item [idNo=" + idNo +", title=" + title + ",copies=" +copies +"]";
		}
	
	public abstract void equals();
	public abstract void CheckIn();
	public abstract void CheckOut();
	public abstract void addItem();
	public abstract void printDetails();
}
