
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Lab8Exercise3
{
		public static void main(String[] args)  throws IOException 
		{
			
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter File Name....");
			String file=br.readLine();
			int linecount=0, wordCount=0, charCount=0;
			try
			{
				FileReader f=new FileReader(file);
				BufferedReader buffr=new BufferedReader(f);
				String currLine=buffr.readLine();
				while(currLine !=null)
				{
					linecount++;
					String words[]=currLine.split("");
					wordCount=wordCount+words.length;
					for(String charc:words)
					{
						charCount=charCount+charc.length();
					}
				currLine=buffr.readLine();
				}
				System.out.println("Lines are "+linecount);
				System.out.println("Words are "+wordCount);
				System.out.println("character are "+charCount);
			}
			catch(IOException ex)
			{
				System.out.println("Exception is "+ex);
			}
		}
}
