
import java.util.Scanner;

public class Lab8Exercise5 {

	public static boolean checkPositive(String str) {
		boolean bq=false;
		int len=str.length();
		System.out.println(len);
		for(int i=len-1;i>0;i--)
		{
			if(str.charAt(i-1)<str.charAt(i))
				bq=true;
			else
				bq=false;
		}
		return bq;
		}

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter String");
		String str=sc.nextLine();
		boolean ba=checkPositive(str);
		if(ba)
		{
			System.out.println("The String is Positive");
		}
		else
		{
			System.out.println("The String is not Positive");
		}
		
	}

}
