
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Lab9Exercise1 
{
	public static HashMap<String, Integer> sortByValue(HashMap<String, Integer>h)
	{
		
		List<Map.Entry<String, Integer> >list=new LinkedList<Map.Entry<String,Integer> >(h.entrySet());
		
	
	Collections.sort(list, new Comparator<Map.Entry<String, Integer> >()
			{
		public int compare(Map.Entry<String, Integer> o1,Map.Entry<String,Integer> o2)
		{
		return(o1.getValue()).compareTo(o2.getValue());
			}
});
	
	
	HashMap<String, Integer>temp=new LinkedHashMap<String,Integer>();
	for(Map.Entry<String, Integer>aa:list)
	{
		temp.put(aa.getKey(), aa.getValue());
	}
	return temp;
	}
	
	public static void main(String[] args) {
		HashMap<String, Integer>h=new HashMap<String,Integer>();
		h.put("Hemanth", 18);
		h.put("Sang", 40);
		h.put("Study",91);
		h.put("Exam",92);
		h.put("Java",79);
		h.put("Advance Java",80);
		Map<String,Integer>h1=sortByValue(hm);
		for(Map.Entry<String, Integer>en:h1.entrySet())
		{
			System.out.println("Key="+en.getKey() +",Value="+en.getValue());
		}
		
		

	}

}
