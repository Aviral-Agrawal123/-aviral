import java.util.Scanner;
import java.util.function.UnaryOperator;
@FunctionalInterface
interface AddSpace
{
	public void add(String str);
}

public class Lab13Exercise2 {

	public static void main(String[] args) {
		UnaryOperator<String> a=(str)->{
			String res ="";
			for(int i=0;i<str.length();i++)
			{
				
					res=res+(str.charAt(i));
					if(i==str.length()-1)
						break;
					res=res +' ';
						}
				return res;
						};
						Scanner sc=new Scanner(System.in);
						System.out.println("Enter the String ");
						String str=sc.nextLine();
						String s=a.apply(str);
						System.out.println(s);
			}
		}