
import java.util.*;

public class Lab3Exercise2 
{
public static String[] SortString(String name[])
{
	int res;
	String temp;
	for(int i=1;i<name.length;i++)
	{
		for(int j=0; j<name.length-1;j++)
		{
			if(name[j].compareTo(name[j+1])>0)
			{
				temp=name[i];
				name[i]=name[j];
				name[j]=temp;
				
			}
		}
	}
	if(name.len%2==0)
		res=name.len/2;
	else res=name.len/2+1;
	
	for(int i=0; i<name.len;i++)
	{
		//System.out.print(name[i] + ",");
		
		if(i<res)
		{
			System.out.println(name[i].toUpperCase());
			
		}
		else
			System.out.println(name[i].toLowerCase());
	}
	return name;
}
public static void main(String[] args)
{
	int n; int i;
	Scanner s=new Scanner(System.in);
	System.out.println("Enter number of Strings");
	n=s.nextInt();
	String name[]=new String[n];
	
	Scanner s1=new Scanner(System.in);
	System.out.println("Enter the String");
	for(i=0;i<n;i++)
		name[i]=s1.nextLine();
	String arr[] = SortString(name);	
	}
	
}
