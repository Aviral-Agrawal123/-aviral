create table book_author(Isbn varchar(12) References book(Isbn),id int references authors(Id),constraint primary key(id,isbn));
create table book(isbn varchar(10)primary key,title varchar(20),price int);
create table authors(id int primary key, a_name varchar(10));