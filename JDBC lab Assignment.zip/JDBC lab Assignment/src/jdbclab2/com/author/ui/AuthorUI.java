package jdbclab2.com.author.ui;
import java.util.ArrayList;
import java.util.Scanner;

import jdbclab2.com.author.bean.Author;
import jdbclab2.com.author.dao.AuthorDao;

public class AuthorUI
{
public static void main(String[] args) 
{
	AuthorDao Dao=new AuthorDao();		
	Scanner s=new Scanner(System.in);
	Author a=new Author();
	int choice ;
	System.out.println("User enter your Choice\n1 for create\n2 for display\n3 for update\n4 for delete\n5 for exit ");
	choice=s.nextInt();
	switch(choice)
	{
	case 1:
	System.out.println("Enter the number of author you want to add");
	int n=s.nextInt();
	for(int i=0;i<n;i++)
	{
	System.out.println("Enter author details\nEnter the id of author");
	int Eid=s.nextInt();
	a.setAuthor_Id(Eid);
	System.out.println("Enter the first name");
	String fname=s.next();
	a.setFirstName(fname);
	System.out.println("Enter the middle name");
	String mname=s.next();
	a.setMiddleName(mname);
	System.out.println("Enter the last name");
	s.nextLine();
	String lname=s.next();
	a.setLastName(lname);
	s.nextLine();
	System.out.println("Enter the phone no");
	String phoneNo=s.next();
	a.setPhoneNo(phoneNo);
	int row=Dao.addEmployee(a);
	System.out.println(row+"row added successfully");
	}
	break;
	case 2:
	ArrayList<Author> List=Dao.display();
	for (Author author : List) {
		System.out.println(author.getFirstName());
	}
		break;
	case 3:
		System.out.println("Change the number");
		String phone=s.next();
		int i=Dao.updateEmployee(phone);
		System.out.println(i+"row updated");
		break;
	case 4:
		Dao.deleteEmployee();
		break;
	case 5:
		System.out.println("thank you");
		System.exit(0);
	default: 
		System.out.println("try again!!");
}
	System.out.println("User enter your Choice\n1 for create\n2 for display\n3 for update\n4 for delete\n5 for exit ");
	choice=s.nextInt();
}
}
