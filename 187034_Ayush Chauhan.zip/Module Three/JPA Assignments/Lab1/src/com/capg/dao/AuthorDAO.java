package com.capg.dao;

import com.capg.entities.Author;

public interface AuthorDAO {
	
	public void addAuthor(Author a);
	public void removeAuthor(Author a);
	public void updateAuthor(Author a);
	public Author findAuthor(int aid);

}
